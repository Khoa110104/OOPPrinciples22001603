package oop.principles.abstraction;

abstract public class Animal {
    abstract public void greeting();
}
