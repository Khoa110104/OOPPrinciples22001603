package oop.principles.abstraction;

public class Dog extends Animal {
    @Override
    public void greeting() {
        System.out.println("Woof!");
    }
}
