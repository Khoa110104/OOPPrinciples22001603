package oop.principles.abstraction;

public class Cat extends Animal {

    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}
