package hus.oop.midterm.students;

public interface StudentComparator {
    int compare(Student left, Student right);
}
