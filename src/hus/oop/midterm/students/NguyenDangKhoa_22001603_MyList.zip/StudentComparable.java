package hus.oop.midterm.students;

public interface StudentComparable {
    int compareTo(Student another);
}
