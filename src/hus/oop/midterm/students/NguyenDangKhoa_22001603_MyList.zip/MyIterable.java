package hus.oop.midterm.students;

public interface MyIterable {
    MyIterator iterator();
}
